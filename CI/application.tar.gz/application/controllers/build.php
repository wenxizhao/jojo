<?php
include_once '../ChromePhp.php';
class Build extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));	  
	  	$this->load->library('form_validation');
		$this->load->model('build_model');
	}
	public function index()
	{
		$data['builds']=$this->build_model->get_buids();
		$data['title']='builds list';
		$this->load->view('templates/header',$data);
		$this->load->view('build/index',$data);
		$this->load->view('templates/footer');
	}
	public function buildinfo($bid = NULL,$build_name = NULL)
	{
		if($bid==NULL || $build_name==NULL)
		{
			$build=$this->build_model->default_build();
			$bid=$build['id'];
			$build_name=$build['name'];
		}		
		$data['build_info']=$this->build_model->get_buildinfo($bid);
		$data['build_name']=$build_name;
		$data['build_id']=$bid;
		$data['title']=$build_name;
		$this->load->view('templates/header',$data);
		$this->load->view('build/buildinfo',$data);
		$this->load->view('templates/footer');
	}
	public function chart($pid=NULL,$pname=NULL)
	{
		$data['title']='chart';
		$data['pname']=$pname;
		$data['dolphin']=$this->build_model->get_performance($pid,'dolphin');
		$data['uc']=$this->build_model->get_performance($pid,'uc');
		$this->load->view('templates/header',$data);
		$this->load->view('build/chart',$data);
		$this->load->view('templates/footer');
	}
	public function detail($bid=NULL)
	{
		$data['title']='detail info';
		$data['bname']='***';
		$data['value']=$this->build_model->get_totallyloaded($bid);
		$this->load->view('templates/header',$data);
		$this->load->view('build/detail',$data);
		$this->load->view('templates/footer');
		
	}

}
?>