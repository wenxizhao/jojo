<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="shortcut icon" href="http://cn.dolphin-browser.com/fancybox/favicon.ico" type="image/x-icon" />
<style type="text/css" title="currentStyle">
            @import "<?php echo base_url("buildstyle/DataTables/media/css/demo_table.css");?>";
            @import "<?php echo base_url("buildstyle/DataTables/media/css/demo_page.css")?>";
</style>
<script type="text/javascript" language="javascript" src="<?php echo base_url("buildstyle/DataTables/media/js/jquery.js")?>"></script>
<script type="text/javascript" language="javascript" src="<?php echo base_url("buildstyle/DataTables/examples/examples_support/jquery.jeditable.js")?>"></script>
<script type="text/javascript" language="javascript" src="<?php echo base_url("buildstyle/DataTables/media/js/jquery.dataTables.js")?>"></script>
<script src="<?php echo base_url("buildstyle/Highcharts/js/highcharts.js")?>"></script>
<script src="<?php echo base_url("buildstyle/Highcharts/js/modules/exporting.js")?>"></script>
<title><?php echo $title?></title>
</head>