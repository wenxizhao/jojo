<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html>
<head>
  <title>Web test Site</title>
  <link rel='stylesheet' type='text/css' href='<?php echo base_url("css/mystyles.css");?>' media='all'/>
</head>
<body>

hello world!

</body>
</html>